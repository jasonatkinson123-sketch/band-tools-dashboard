import {
  Transport
} from './audio.js';
import {
  Microphone
} from './microphone.js';
import {
  parseStructured
} from './structured.js';
import {
  exportPack,
  importPack,
  mapRows
} from './model.js';
import {
  db
} from './common.js';
const out = document.querySelector('#results'),
  wait = ms => new Promise(r => setTimeout(r, ms));
const assert = (v, label) => {
  if (!v) throw Error(label);
  out.textContent += 'PASS ' + label + '\n'
};

function wav(seconds, hz) {
  let samples = seconds * 24000;
  const bytes = new ArrayBuffer(44 + samples * 2),
    v = new DataView(bytes);
  for (const [s, i] of [
      ['RIFF', 0],
      ['WAVE', 8],
      ['fmt ', 12],
      ['data', 36]
    ])
    for (let j = 0; j < s.length; j++) v.setUint8(i + j, s.charCodeAt(j));
  for (const [i, n] of [
      [4, bytes.byteLength - 8],
      [16, 16],
      [24, 24000],
      [28, 48000],
      [40, samples * 2]
    ]) v.setUint32(i, n, true);
  for (const [i, n] of [
      [20, 1],
      [22, 1],
      [32, 2],
      [34, 16]
    ]) v.setUint16(i, n, true);
  for (let i = 0; i < samples; i++) v.setInt16(44 + i * 2, 6000 * Math.sin(2 * Math.PI * hz * i / 24000), true);
  return new File([bytes], 'tone.wav', {
    type: 'audio/wav'
  })
}

function freq(buffer, start, end) {
  const ch = buffer.getChannelData(0),
    a = Math.floor(start * buffer.sampleRate),
    b = Math.min(ch.length, Math.floor(end * buffer.sampleRate));
  let count = 0;
  for (let i = a + 1; i < b; i++)
    if (ch[i - 1] <= 0 && ch[i] > 0) count++;
  return count * buffer.sampleRate / (b - a)
}
document.querySelector('#run').onclick = async () => {
  document.querySelector('#run').disabled = true;
  out.textContent = '';
  let engine, mic;
  try {
    engine = new Transport(() => {});
    const ctx = await engine.unlock(),
      song = await fetch('./demo/demo.json').then(r => r.json());
    const xs = await Promise.all(['First-Light.musicxml', 'First-Light.mid'].map(async name => parseStructured(
      new File([await fetch('./demo/' + name).then(r => r.blob())], name))));
    for (const [i, x] of xs.entries()) assert(x.parts.length === 9 && x.notes.length === 308 && x.measures
      .length === 16 && Math.abs(x.duration - 40) < .001, ['MusicXML', 'MIDI'][i] +
      ' browser import, complete 9-part study');
    const mx = new JSZip();
    mx.file('META-INF/container.xml',
      '<container><rootfiles><rootfile full-path="score.musicxml" media-type="application/vnd.recordare.musicxml+xml"/></rootfiles></container>'
      );
    mx.file('score.musicxml', await fetch('./demo/First-Light.musicxml').then(r => r.text()));
    const zipped = await mx.generateAsync({
      type: 'blob'
    });
    assert((await parseStructured(new File([zipped], 'study.mxl'))).notes.length === 308,
      'compressed MXL opens the container score');
    let bad = false;
    try {
      mapRows('1,0,2.5\n2,1,5', 5)
    } catch {
      bad = true
    }
    assert(bad, 'overlapping measure map rejected');
    const wave = wav(2, 220),
      test = {
        ...song,
        id: 'test-tone',
        mix: wave,
        mixDuration: 2,
        stems: [{
          part: 'flute',
          file: wave,
          duration: 2
        }, {
          part: 'horn',
          file: wave,
          duration: 2
        }]
      };
    engine.rate = .75;
    await engine.prepare(test, 'stems');
    assert(engine.prepared.length === 2 && Math.abs(engine.prepared[0].buffer.duration - 2 / .75) < .001,
      'two stems share the stretched sample clock');
    const hz = freq(engine.prepared[0].buffer, .3, 1.8);
    assert(Math.abs(hz - 220) < 3, '75% tempo retains 220 Hz pitch (' + hz.toFixed(1) + ' Hz)');
    engine.mute('flute');
    engine.start({
      song: test,
      mode: 'stems',
      from: .2,
      to: .5,
      loop: true,
      count: false
    });
    await wait(1150);
    assert(engine.playing && engine.position >= .2 && engine.position < .5 && engine.bus('flute').gain.value === 0,
      'passage wraps with its assigned stem muted');
    engine.stop();
    const pos = engine.position;
    await wait(60);
    assert(engine.position === pos, 'pause holds source position');
    const src = ctx.createOscillator(),
      vol = ctx.createGain(),
      input = ctx.createMediaStreamDestination();
    src.frequency.value = 330;
    vol.gain.value = .18;
    src.connect(vol).connect(input);
    src.start();
    let meter = 0;
    mic = new Microphone(engine, v => meter = Math.max(v, meter), async () => input.stream);
    await mic.enable();
    const recorded = new Promise(resolve => mic.record(true, resolve));
    engine.rate = 1;
    await engine.prepare(test, 'mix');
    engine.pos = 0;
    engine.start({
      song: test,
      mode: 'mix',
      from: 0,
      to: 2,
      loop: false,
      count: false
    });
    await wait(1200);
    mic.stop();
    engine.stop();
    const blob = await recorded;
    assert(blob.size > 1000 && meter > 0, 'live Web Audio test input reached meter and MediaRecorder');
    const decoded = await ctx.decodeAudioData(await blob.arrayBuffer());
    let peak = 0;
    for (const v of decoded.getChannelData(0)) peak = Math.max(peak, Math.abs(v));
    assert(decoded.duration > .75 && peak > .03, 'recorded take decodes to audible samples');
    const player = new Audio(URL.createObjectURL(blob));
    player.muted = true;
    await player.play();
    await wait(150);
    assert(player.currentTime > 0, 'recorded take plays through the browser audio element');
    player.pause();
    URL.revokeObjectURL(player.src);
    mic.disable();
    src.stop();
    const track = {
      id: crypto.randomUUID(),
      date: Date.now(),
      blob
    };
    await db('takes', 'put', track);
    const persisted = await db('takes', 'get', track.id);
    assert(persisted.blob.size === blob.size, 'recorded take persists in IndexedDB');
    await db('takes', 'delete', track.id);
    const pdf = await fetch('./sleightest.pdf').then(r => r.blob());
    test.parts = [{
      id: 'flute',
      name: 'Flute',
      pdfBlob: pdf,
      pageCount: 1
    }, {
      id: 'horn',
      name: 'Horn'
    }];
    const pack = await exportPack(test),
      reopened = await importPack(pack, new Map());
    assert(reopened.parts[0].pdfBlob.size === pdf.size && reopened.stems.length === 2 && reopened.mix.size === wave
      .size, 'practice pack round-trip preserves PDF, mix and both stems');
    const lib = await import('./vendor/pdf/pdf.min.mjs');
    lib.GlobalWorkerOptions.workerSrc = './vendor/pdf/pdf.worker.min.mjs';
    const pdfDoc = await lib.getDocument({
      data: new Uint8Array(await pdf.arrayBuffer())
    }).promise;
    const pdfPage = await pdfDoc.getPage(1),
      vp = pdfPage.getViewport({
        scale: 1
      });
    const can = document.createElement('canvas');
    can.width = vp.width;
    can.height = vp.height;
    await pdfPage.render({
      canvasContext: can.getContext('2d'),
      viewport: vp
    }).promise;
    assert(can.width > 0, 'imported PDF page renders through PDF.js');
    await pdfDoc.destroy();
    for (const width of [390, 768, 1366]) {
      const frame = document.createElement('iframe');
      frame.style.cssText = 'width:' + width + 'px;height:680px;display:block';
      frame.src = './?piece=first-light&part=tenor&from=5&to=8&loop=1&speed=75';
      await new Promise(r => {
        frame.onload = r;
        document.querySelector('#viewport').append(frame)
      });
      const doc = frame.contentDocument;
      for (let i = 0; i < 80 && !doc.querySelector('#sheet img'); i++) await wait(50);
      const fits = doc.documentElement.scrollWidth <= doc.documentElement.clientWidth + 1;
      assert(fits && doc.querySelector('#part').value === 'tenor' && doc.querySelector('#loop').checked && doc
        .querySelector('#start').value === '5' && doc.querySelector('#speed').value === '75', width +
        'px student layout and assignment link');
      frame.remove()
    }

    const fixtureId = crypto.randomUUID(),
      fixture = {
        ...song,
        id: fixtureId,
        title: 'Studio test ' + fixtureId,
        parts: [{
          id: 'flute',
          name: 'Fixture flute',
          pdfBlob: pdf,
          pageCount: 1
        }],
        notes: [],
        duration: 0,
        measures: [],
        sections: [],
        bpm: 96,
        mix: wave,
        mixDuration: 2,
        mixMap: [{
          n: 1,
          t: 0,
          end: 1
        }, {
          n: 2,
          t: 1,
          end: 2
        }],
        mixSections: [{
          name: 'Ending',
          from: 2,
          to: 2
        }]
      };
    const frame = document.createElement('iframe');
    frame.style.cssText = 'width:768px;height:800px';
    const until = async (fn, label) => {
      for (let i = 0; i < 140; i++) {
        if (fn()) return;
        await wait(50)
      }
      throw Error('Timeout: ' + label+'; '+(frame.contentDocument?.getElementById('notice')?.textContent||'')+'; '+(frame.contentDocument?.getElementById('lastTake')?.textContent||'')+'; '+(frame.contentDocument?.getElementById('takesList')?.textContent||''))
    };
    try {
      await db('pieces', 'put', fixture);
      frame.src = './?piece=' + fixtureId + '&part=flute';
      await new Promise(r => {
        frame.onload = r;
        document.querySelector('#viewport').append(frame)
      });
      const w = frame.contentWindow,
        doc = frame.contentDocument,
        el = id => doc.getElementById(id);
      await until(() => doc.querySelector('#sheet canvas'), 'student PDF');
      doc.querySelector('[data-view="teacher"]').click();
      await until(() => el('mapText'), 'teacher editor');
      el('sectionsText').value = 'Opening,1,1';
      el('saveMap').click();
      await until(() => el('notice').textContent.includes('Timing and sections saved'), 'save teacher changes');
      el('preview').click();
      await until(() => el('passage').textContent.includes('Opening'), 'saved teacher map preview');
      assert(el('part').value === 'flute', 'teacher timing edits persist in exact student preview');
      const source = ctx.createOscillator(),
        g = ctx.createGain(),
        feed = ctx.createMediaStreamDestination();
      g.gain.value = .16;
      source.connect(g).connect(feed);
      source.start();
      const capture = w.navigator.mediaDevices.getUserMedia.bind(w.navigator.mediaDevices);
      w.navigator.mediaDevices.getUserMedia = async () => {
        throw new w.DOMException('Test denial', 'NotAllowedError')
      };
      el('micBtn').click();
      await until(() => el('notice').textContent.includes('permission was denied'), 'microphone denial');
      assert(!el('record').disabled, 'microphone denial leaves recording controls recoverable');
      w.navigator.mediaDevices.getUserMedia = async () => feed.stream;
      el('count').checked = false;
      el('record').click();
      await until(() => el('record').textContent.includes('Stop & save'), 'start real UI capture');
      await wait(650);
      el('record').click();
      await until(() => el('lastTake').querySelector('audio'), 'record saved through UI');
      doc.querySelector('[data-view="takes"]').click();
      await until(() => el('takesList').textContent.includes(fixture.title) && el('history').textContent.includes(fixture.title), 'takes list and history');
      assert(el('takesList').querySelector('audio') && el('history').textContent.includes(fixture.title),
        'record button saves a replayable take and practice history');
      source.stop();
      w.navigator.mediaDevices.getUserMedia = capture;
    } finally {
      frame.remove();
      await db('pieces', 'delete', fixtureId);
      for (const store of ['takes', 'history'])
        for (const row of await db(store, 'getAll'))
          if (row.title === fixture.title) await db(store, 'delete', row.id)
    }
    out.textContent += 'ALL BROWSER CHECKS PASSED';
  } catch (e) {
    out.textContent += 'FAIL ' + e.message + '\n' + e.stack
  } finally {
    engine?.stop();
    mic?.disable();
    document.querySelector('#run').disabled = false
  }
}
