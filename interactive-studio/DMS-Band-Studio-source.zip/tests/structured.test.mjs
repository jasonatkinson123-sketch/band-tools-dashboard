// Run: node --test tests/structured.test.mjs (requires python3 for XML fixture parsing).
// The product uses the browser's native DOMParser. This test adapter supplies
// only the subset of Element APIs used here without imposing a production dependency.
import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { parseStructured } from '../dist/structured.js';

const pythonParse = `
import sys,json,xml.etree.ElementTree as ET
def data(e):
    return [e.tag.rsplit('}',1)[-1], e.attrib, ''.join(e.itertext()), [data(c) for c in e]]
try: print(json.dumps(data(ET.fromstring(sys.stdin.read()))))
except ET.ParseError: print(json.dumps(['parsererror', {}, 'invalid XML', []]))
`;
function element([localName, attrs, textContent, nested]) {
  const children = nested.map(element);
  return {
    localName, children, textContent,
    getAttribute: k => attrs[k] ?? null, hasAttribute: k => Object.hasOwn(attrs, k),
    getElementsByTagNameNS(_, k) {
      return children.flatMap(c => [...(c.localName === k ? [c] : []), ...c.getElementsByTagNameNS('*', k)]);
    }
  };
}
globalThis.DOMParser = class {
  parseFromString(xml) {
    const root = element(JSON.parse(execFileSync('python3', ['-c', pythonParse], { input: xml, encoding: 'utf8' })));
    return { documentElement: root, getElementsByTagNameNS: (_, k) => root.localName === k ? [root] : root.getElementsByTagNameNS('*', k) };
  }
};
const music = (value, name) => new File([value], name);
const midi = (...tracks) => {
  const head = [77,84,104,100,0,0,0,6,0,tracks.length === 1 ? 0 : 1,0,tracks.length,0,96];
  const chunks = tracks.flatMap(t => [77,84,114,107,0,0,t.length >> 8,t.length & 255,...t]);
  return music(Uint8Array.from([...head, ...chunks]), 'fixture.mid');
};
const stop = [0,255,47,0];
const xml = measures => music('<score-partwise version="4.0"><part-list><score-part id="P1"><part-name>B-flat Clarinet</part-name></score-part></part-list><part id="P1">' + measures + '</part></score-partwise>', 'fixture.musicxml');
const note = (step, duration, extras = '', prefix = '') => '<note>' + prefix + '<pitch><step>' + step + '</step><octave>4</octave></pitch><duration>' + duration + '</duration>' + extras + '</note>';
const att = '<attributes><divisions>2</divisions><time><beats>3</beats><beat-type>4</beat-type></time><transpose><chromatic>-2</chromatic></transpose></attributes>';

test('format 1 conductor tempo and meter changes apply across named tracks', async () => {
  const f = midi(
    [0,255,81,3,7,161,32, 0,255,88,4,3,2,24,8, 0x82,0x20,255,81,3,15,66,64, 0,255,88,4,2,2,24,8, ...stop],
    [0,255,3,4,72,111,114,110,0,0x90,60,64, 0x82,0x20,60,0, 0,64,64, 0x81,0x40,64,0, ...stop],
    [0,0x91,67,64,96,0x81,67,0, ...stop]
  );
  const r = await parseStructured(f);
  assert.deepEqual(r.parts, [{ id:'midi-2-1', name:'Horn' },{id:'midi-3-2',name:'Track 3'}]);
  assert.deepEqual(r.measures, [{n:1,t:0,end:1.5},{n:2,t:1.5,end:3.5}]);
  assert.deepEqual(r.notes.map(n => [n.midi,n.t,n.d]), [[60,0,1.5],[67,0,0.5],[64,1.5,2]]);
  assert.equal(r.duration,3.5);
});
test('format 0 running status, sustain and channel splits', async () => {
  const r = await parseStructured(midi([0,0xb0,64,127,0,0x90,60,100,0,0x91,65,80,96,0x81,65,0,0,0x80,60,0,96,0xb0,64,0,...stop]));
  assert.equal(r.parts.length,2);
  assert.deepEqual(r.notes.map(n => [n.midi,n.d]).sort((a,b)=>a[0]-b[0]),[[60,1],[65,0.5]]);
});
test('parse XML pickup, sounding transposition, ties, chord and tempo changes', async () => {
  const fixture = '<measure number="0" implicit="yes">' + att + '<direction><sound tempo="60"/></direction>' + note('C',2,'<tie type="start"/>') + '</measure>'
    + '<measure number="1"><direction><direction-type><rehearsal>A</rehearsal></direction-type><sound tempo="120"/></direction>'
    + note('C',2,'<tie type="stop"/>') + note('E',2) + note('G',2,'','<chord/>') + '<note><rest/><duration>2</duration></note></measure>';
  const r = await parseStructured(xml(fixture));
  assert.deepEqual(r.parts,[{id:'xml-P1',name:'B-flat Clarinet'}]);
  assert.deepEqual(r.measures,[{n:1,t:0,end:1,label:'Printed m. 0'},{n:2,t:1,end:2.5,label:'A'}]);
  assert.deepEqual(r.notes.map(n => [n.midi,n.t,n.d]),[[58,0,1.5],[62,1.5,0.5],[65,1.5,0.5]]);
});
test('dual voices, tenor octave-transposition and dotted tempo marks', async () => {
  const a = att.replace('-2</chromatic>', '-2</chromatic><octave-change>-1</octave-change>');
  const direction = '<direction><direction-type><metronome><beat-unit>quarter</beat-unit><beat-unit-dot/><per-minute>80</per-minute></metronome></direction-type></direction>';
  const fixture = '<measure number="1">'+a+direction+note('D',6,'<voice>1</voice>')+'<backup><duration>6</duration></backup>'+note('F',6,'<voice>2</voice>')+'</measure>';
  const r = await parseStructured(xml(fixture));
  assert.equal(r.bpm,120); assert.equal(r.duration,1.5);
  assert.deepEqual(r.notes.map(n=>[n.midi,n.t,n.d]),[[48,0,1.5],[51,0,1.5]]);
});
test('reject malformed files and ambiguous playback navigation', async () => {
  for (const f of [
    music('MThd','broken.mid'), music('PKtest','compressed.mxl'), music('<','bad.xml'),
    xml('<measure number="1">'+att+note('C',2)+'<barline><repeat direction="backward"/></barline></measure>'),
    xml('<measure number="1">'+att+note('C',2)+'<direction><direction-type><words>D.C. al Fine</words></direction-type></direction></measure>'),
    xml('<measure number="1">'+att+'<backup><duration>2</duration></backup>'+note('C',2)+'</measure>')
  ]) await assert.rejects(() => parseStructured(f));
});
